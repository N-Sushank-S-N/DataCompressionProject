// server.js
const express = require('express');
const multer  = require('multer');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const helmet = require('helmet');
const archiver = require('archiver');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.static(path.join(__dirname, 'public')));

const TMP = path.join(__dirname, 'tmp');
if (!fs.existsSync(TMP)) fs.mkdirSync(TMP, { recursive: true });

const upload = multer({
  dest: TMP,
  limits: { fileSize: 150 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (ext === '.wav') cb(null, true);
    else cb(new Error('Only .wav files allowed'));
  }
}).array('wavfile', 50);

function safeName(original) {
  return path.basename(original).replace(/[^a-zA-Z0-9\.\-_]/g, '_');
}

function checkFFmpeg() {
  return new Promise((res) => {
    const p = spawn('ffmpeg', ['-version']);
    p.on('error', () => res(false));
    p.on('exit', (code) => res(code === 0 || code === null));
  });
}

(async () => {
  const ok = await checkFFmpeg();
  if (!ok) {
    console.error('ffmpeg not found in PATH. Install ffmpeg and restart.');
    process.exit(1);
  }
})();

function convertWithCodec(inputPath, outPath, codec) {
  return new Promise((resolve, reject) => {
    const args = ['-y', '-hide_banner', '-loglevel', 'error', '-i', inputPath, '-c:a', codec, outPath];
    const ff = spawn('ffmpeg', args);
    ff.on('error', (e) => reject(new Error('Failed to start ffmpeg: ' + e.message)));
    ff.on('exit', (code) => {
      if (code !== 0) return reject(new Error(`ffmpeg exit code ${code}`));
      resolve(outPath);
    });
  });
}

app.post('/api/convert', (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      console.error('Upload error:', err.message || err);
      return res.status(400).json({ success: false, error: err.message || 'Upload failed' });
    }
    const files = req.files || [];
    if (!files.length) return res.status(400).json({ success: false, error: 'No files uploaded' });

    const jobId = uuidv4();
    const outFiles = [];

    try {
      for (const f of files) {
        const origSafe = safeName(f.originalname);
        const baseName = path.parse(origSafe).name;

        // 1) WAV -> WavPack (.wv) using codec 'wavpack'
        const wvName = `${baseName}-${uuidv4()}.wv`;
        const wvPath = path.join(TMP, wvName);
        await convertWithCodec(f.path, wvPath, 'wavpack');
        outFiles.push({ orig: f.originalname, type: 'wavpack', outPath: wvPath, outName: wvName });

        // 2) WAV -> FLAC (.flac)
        const flacName = `${baseName}-${uuidv4()}.flac`;
        const flacPath = path.join(TMP, flacName);
        await convertWithCodec(f.path, flacPath, 'flac');
        outFiles.push({ orig: f.originalname, type: 'flac', outPath: flacPath, outName: flacName });

        // schedule cleanup for uploaded WAV soon
        scheduleCleanup(f.path, 2 * 60 * 1000);
      }

      // Create zip containing all outputs
      const zipName = `wav2pack-flac-${jobId}.zip`;
      const zipPath = path.join(TMP, zipName);

      await new Promise((resolve, reject) => {
        const output = fs.createWriteStream(zipPath);
        const archive = archiver('zip', { zlib: { level: 9 } });
        output.on('close', () => resolve());
        archive.on('error', (err) => reject(err));
        archive.pipe(output);
        // Add files using original base names; if collisions happen, zip will handle with duplicate names (but unique names used in fs)
        for (const ofi of outFiles) {
          const ext = path.extname(ofi.outName); // .wv or .flac
          const entryName = `${path.parse(ofi.orig).name}${ext}`;
          archive.file(ofi.outPath, { name: entryName });
        }
        archive.finalize();
      });

      // schedule cleanup
      scheduleCleanup(zipPath, 10 * 60 * 1000);
      outFiles.forEach(o => scheduleCleanup(o.outPath, 10 * 60 * 1000));

      return res.json({ success: true, downloadUrl: `/download/${path.basename(zipPath)}`, filename: zipName });
    } catch (e) {
      console.error('Conversion process error:', e);
      const toClean = files.map(f => f.path).concat(outFiles.map(o => o.outPath));
      cleanupFiles(toClean);
      return res.status(500).json({ success: false, error: e.message || 'Conversion failed' });
    }
  });
});

app.get('/download/:file', (req, res) => {
  const file = path.basename(req.params.file);
  const full = path.join(TMP, file);
  if (!fs.existsSync(full)) return res.status(404).send('File not found or expired');
  res.download(full, file, (err) => {
    if (err) console.error('Download error', err);
    scheduleCleanup(full, 30 * 1000);
  });
});

function cleanupFiles(list) {
  list.forEach((f) => {
    if (f && fs.existsSync(f)) {
      try { fs.unlinkSync(f); } catch (e) { /* ignore */ }
    }
  });
}
function scheduleCleanup(filePath, ms) {
  setTimeout(() => {
    try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch (e) {}
  }, ms);
}

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`wav→pack+flac server listening: http://localhost:${PORT}`);
});