# wav2flac-local

Local WAV → WavPack + FLAC converter with a minimal web UI (multi-file + ZIP support).

## Requirements
- ffmpeg installed and available in PATH (`ffmpeg -version`).
- Node.js v16+ and npm.

## Install & run
```bash
npm install
npm start